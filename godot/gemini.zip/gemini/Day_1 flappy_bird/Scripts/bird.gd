extends CharacterBody2D
@export var jump_force := -350.0
@export var gravity := 900.0

var is_dead = false

func _physics_process(delta):
	if is_dead:
		return
	velocity.y += gravity * delta
	if Input.is_action_just_pressed("ui_accept"):
		velocity.y = jump_force
	if Input.is_action_just_pressed("reset"):
		get_tree().reload_current_scene()

	move_and_slide()

func die():
	is_dead = true

func _on_body_entered(body):
	die()
	#GameManager.end_game()
