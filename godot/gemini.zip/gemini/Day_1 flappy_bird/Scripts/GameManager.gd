extends Node
signal score_changed(score)

var score = 0
var game_over = false

func add_score():
	if game_over:
		return
	score += 1
	score_changed.emit(score)

func end_game():
	game_over = true
	get_tree().paused = true

func restart():
	get_tree().paused = false
	get_tree().reload_current_scene()
