extends Node2D

@export var move_speed := 200

func _process(delta):
	position.x -= move_speed * delta

	if position.x < -300:
		queue_free()
