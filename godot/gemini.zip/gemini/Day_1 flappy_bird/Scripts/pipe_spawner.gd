extends Node2D

@export var pipe_scene : PackedScene
@export var spawn_rate := 1.5
@export var pipe_gap := 250

func _ready():
	$Timer.wait_time = spawn_rate
	$Timer.start()

func _on_timer_timeout():
	var pipe = pipe_scene.instantiate()
	pipe.position.x = 900
	pipe.position.y = randf_range(-150,150)
	add_child(pipe)
