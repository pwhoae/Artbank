extends Area2D

func _on_body_entered(body):

	if body.name == "Bird":
		pass
		#GameManager.add_score()
