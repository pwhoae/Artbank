extends Control
@onready var GameManager=$"../../GameManager" 

func _ready():
	pass
	GameManager.score_changed.connect(update_score)

func update_score(score):
	$ScoreLabel.text = str(score)
