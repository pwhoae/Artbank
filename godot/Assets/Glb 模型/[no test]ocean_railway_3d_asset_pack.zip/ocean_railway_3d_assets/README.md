# Ocean Railway 3D Environment Asset Pack

- Format: GLB (glTF 2.0)
- Units: meters
- Up axis: Y
- Import: Three.js `GLTFLoader`, Blender, Godot (glTF 2.0)
- Main preview scene: `ocean_railway_sample_scene.glb`

## Assets
- `01_commuter_train.glb` — 雙節藍色通勤列車，含車窗、車門、車輪、車頂設備及車頭燈。
- `02_catenary_gantry.glb` — 架空接觸網門型桁架，含立柱、底座、斜撐、吊柱及絕緣子。
- `03_catenary_pole.glb` — 單柱式接觸網支柱與懸臂支架。
- `04_rail_track_section.glb` — 12 米直線鋼軌模組，含兩條鋼軌、枕木及扣件。
- `05_track_turnout.glb` — 分岔道岔軌道模組，含彎折支線與枕木。
- `06_rail_signal.glb` — 三燈式鐵路號誌機，含紅黃綠燈組、立柱及混凝土基座。
- `07_speed_sign_40.glb` — 限速 40 圓形路旁標誌，含金屬立柱與紅白牌面。
- `08_station_sign.glb` — 藍白色站場識別牌，預留文字貼圖位置。
- `09_signal_cabinet_small.glb` — 鐵路沿線戶外電氣控制箱，含門板、警示標籤、通風細節及混凝土底座。
- `10_power_cabinet_large.glb` — 鐵路沿線戶外電氣控制箱，含門板、警示標籤、通風細節及混凝土底座。
- `11_platform_safety_barrier.glb` — 站台安全護欄，含混凝土基座、立柱與雙層扶手。
- `12_maintenance_ladder.glb` — 鐵路維修直梯。
- `13_safety_bollard.glb` — 黃黑警示防撞柱。
- `14_lifebuoy.glb` — 紅白相間救生圈道具。
- `15_overhead_contact_wire.glb` — 架空接觸線模組，可連接門型架及支柱。

## Three.js quick import
```js
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const loader = new GLTFLoader();
loader.load('./01_commuter_train.glb', (gltf) => scene.add(gltf.scene));
```

These are procedural modular 3D assets inspired by the supplied concept sheet. They are suitable for layout prototyping, scene blocking, and further detailing. They are not photogrammetry or exact reconstructions of a real train system.
